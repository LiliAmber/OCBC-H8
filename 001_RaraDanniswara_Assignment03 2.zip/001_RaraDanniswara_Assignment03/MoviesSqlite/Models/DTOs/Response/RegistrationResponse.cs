using Movies.Configuration;

namespace MoviesJwt.Models.DTOs.Responses
{
    public class RegistrationResponse : AuthResult
    {

    }
}