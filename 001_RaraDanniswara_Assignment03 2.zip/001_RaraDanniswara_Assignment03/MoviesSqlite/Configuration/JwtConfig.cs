namespace MoviesJwt.Configuration
{
    public class JwtConfig 
    {
        public string Secret {get; set;}
    }
}